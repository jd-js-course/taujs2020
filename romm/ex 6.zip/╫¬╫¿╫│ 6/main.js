import {ProjectWithDeadline} from './models/projectWithDeadline.js'
import {Task} from './models/task.js'

const thesis = new ProjectWithDeadline('Thesis project','2020-12-30')


thesis.addTask (new Task('Research', 'Find sources', "2020-12-01", "2020-12-05", 80, null) )
thesis.addTask (new Task('Cite', 'Create bibliography', "2020-12-06", "2020-12-07", 60, 'Research') )
thesis.addTask (new Task('Outline', 'Outline paper', "2020-12-08", "2020-12-10", 80, 'Research'))
thesis.addTask (new Task('Write', 'Write paper', "2020-12-11", "2020-12-20", 40, 'Research, Outline'))
thesis.addTask (new Task('Complete', 'Hand in paper', "2020-12-21", "2020-12-21", 0, 'Cite, Write'))

const myTasks = thesis.getTasks()
const dataTbl = document.getElementById ('dataTbl')

const main = () => {
    dataTbl.innerHTML= ''

for (let i=0; myTasks[i]; i++){

        const el = document.createElement('tr')
        el.innerHTML = '<td>'+myTasks[i].id+'</td><td>'+myTasks[i].name+
                         '</td><td>'+myTasks[i].start+'</td><td>'+myTasks[i].end+'</td><td>'
                         +myTasks[i].progress+'</td><td>'+myTasks[i].dependencies+'</td>'

        const btn = document.createElement('button') 
        btn.className = 'btn btn-danger'
        btn.innerHTML = 'Delete' 
        btn.onclick = () => {
            thesis.removeTaskById(myTasks[i].id)
           main ()
        }        
        dataTbl.appendChild(el)
        dataTbl.appendChild(btn)
    }

    var gantt = new Gantt ("#output", myTasks);
}
 main ()