export class Task {
    id 
    name
    start
    end
    progress
    dependencies

    constructor(id, name, start, end, progress, dependencies){
    this.id=id
    this.name= name
    this.start=start
    this.end=end
    this.progress=progress
    this.dependencies=dependencies 
    }

}
