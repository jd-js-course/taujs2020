import {Project} from './project.js'


export class ProjectWithDeadline extends Project{ 

    deadline

    constructor(title,deadline){
        super(title)
        this.deadline = deadline
    }

    addTask(task) {
        if (task.end > this.deadline){
            console.error('Task' +task.id+ 'is after deadline' +this.deadline)
            return;
        }
        else {
              this.tasks.push(task)
        }    
    }   
}
