 export class Project {

    name

    tasks= []

    constructor (name){
        this.name=name

    }
 
    addTask(task){
        this.tasks.push(task)

    }

    getTasks(){
        return this.tasks
    }

    removeTaskById(id){
      for (let i=0; this.tasks[i]; i++){
          if (this.tasks[i].id == id){
            this.tasks.splice(i, 1)
             }
        }
    }
}